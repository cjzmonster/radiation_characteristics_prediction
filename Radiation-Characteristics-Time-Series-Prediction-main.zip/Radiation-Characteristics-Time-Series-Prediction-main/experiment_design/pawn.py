# -*- coding: utf-8 -*-
"""
Created on Sat Nov 26 10:02:52 2022

@author: Administ
"""

import numpy as np
import pandas as pd
from SALib.analyze import pawn
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--target', type=str, choices=[
                    'ascend_with_earth', 'middle_with_earth', 'whole_with_earth','data_40'], default='data_40')

args = parser.parse_args()

target = args.target

indir = "./data/" + target + "/data207_2.csv"
data = pd.read_csv(indir)
if target == 'data_40':
    mylist = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    _data = data.iloc[:, mylist]  # 10个自变量,除去时间变量
    data_ = data.iloc[:, 13]  # 温度作为因变量
else:
    mylist = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    _data = data.drop(columns='date').iloc[:, mylist]  # 10个自变量,除去时间变量
    data_ = data.drop(columns="date").iloc[:, 18]  # 温度作为因变量
x = _data.values
y = data_.values
# for i in range(14):
#     print(min(x[:,i]), max(x[:,i]))

problem = {
    'num_vars': 10,
    'names': ['长度m', '底面直径mm', '发射率', '吸收率', '防热层厚度mm',
              '防热层热传导率W/m/K', '应力层厚度MM', '应力层热传导率W/m/K',
              '发射时间h', '初温K']
}

index = ['长度m', '底面直径mm', '发射率', '吸收率', '防热层厚度mm',
         '防热层热传导率W/m/K', '应力层厚度MM', '应力层热传导率W/m/K',
         '发射时间h', '初温K']
Si = pawn.analyze(problem, x, y, S=10, print_to_console=True)
column = ['minimum', 'mean', 'median', 'maximum', 'CV']
column_CH = ['最小值', '平均值', '中位数', '最大值', '变异系数']
mine = pd.DataFrame(columns=column_CH, index=index)


for i in range(5):
    mine[mine.columns[i]] = Si[column[i]]

mine.to_excel("./experiment_design/sensitiveness/" + target + ".xlsx")

# 20
#                minimum      mean    median   maximum        CV
# 长度m           0.202214  0.505976  0.502342  0.769411  0.392690
# 底面直径mm        0.147441  0.336214  0.332994  0.528207  0.462396
# 发射率           0.125337  0.471444  0.499689  0.769411  0.461784
# 吸收率           0.415583  0.568259  0.552654  0.769411  0.195378
# 防热层厚度mm       0.240266  0.372273  0.422185  0.454368  0.253210
# 防热层热传导率W/m/K  0.233753  0.509004  0.503320  0.769411  0.470695
# 应力层厚度MM       0.236699  0.442334  0.332994  0.757309  0.511296
# 应力层热传导率W/m/K  0.125337  0.559123  0.570423  0.769411  0.336072
# 发射时间h         0.216182  0.508184  0.511588  0.715204  0.292968
# 初温K           0.233089  0.514106  0.485751  0.769411  0.321518

# 40
#                minimum      mean    median   maximum        CV
# 长度m           0.090985  0.304941  0.273484  0.521594  0.527239
# 底面直径mm        0.139932  0.150567  0.150567  0.161202  0.070633
# 发射率           0.232845  0.349619  0.335949  0.584567  0.272728
# 吸收率           0.154591  0.265023  0.226555  0.519236  0.372927
# 防热层厚度mm       0.126538  0.174301  0.188098  0.208266  0.199439
# 防热层热传导率W/m/K  0.160234  0.392465  0.278299  0.809188  0.527310
# 应力层厚度MM       0.083495  0.107143  0.107143  0.130790  0.220714
# 应力层热传导率W/m/K  0.177425  0.365099  0.339402  0.592729  0.418256
# 发射时间h         0.209635  0.382435  0.337641  0.662266  0.409784
# 初温K           0.241573  0.409543  0.361206  0.626167  0.325213

