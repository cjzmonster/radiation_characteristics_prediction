#! /bin/bash
#SBATCH -J design
#SBATCH -o ./experiment_design/design/bash_result.out               
#SBATCH -p compute                  
#SBATCH --qos=normal               
#SBATCH -N 1               
#SBATCH --ntasks-per-node=1                    
#SBATCH --cpus-per-task=4
#SBATCH --gres=gpu:P40:1

python -u ./experiment_design/design.py --sample_num 20 --sensitiveness_list 0.30 0.15 0.35 0.27 0.17 0.39 0.11 0.37 0.38 0.41