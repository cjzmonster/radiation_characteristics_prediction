#!/bin/bash
#SBATCH -o job.%j_train.out
#SBATCH -p compute2
#SBATCH -A compute2
#SBATCH --qos=compute2
#SBATCH -J 207task
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --gres=gpu:1


python run_longExp.py   \
--is_training 0 \
--model_id test \
--model DLinear \
--data new40 \
--features MS \
--root_path './data/data_40/' \
--data_path 'data207.csv' \
--batch_size 32 \
--seq_len 32 \
--label_len 32 \
--pred_len 32  \
--test_new 1    \
--target tmp \
--num_workers 0 \
--d_ff 2048