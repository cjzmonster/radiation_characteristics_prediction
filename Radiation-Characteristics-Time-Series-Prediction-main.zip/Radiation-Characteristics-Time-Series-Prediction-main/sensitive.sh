#! /bin/bash
#SBATCH -J sensitiveness
#SBATCH -o ./experiment_design/sensitiveness/bash_result.out               
#SBATCH -p compute                  
#SBATCH --qos=normal               
#SBATCH -N 1               
#SBATCH --ntasks-per-node=1                    
#SBATCH --cpus-per-task=4
#SBATCH --gres=gpu:P40:1

python -u ./experiment_design/pawn.py --target data_40