import numpy as np
import torch
import matplotlib.pyplot as plt
import time
import pywt

plt.switch_backend('agg')


def adjust_learning_rate(optimizer, epoch, args):
    # lr = args.learning_rate * (0.2 ** (epoch // 2))
    if args.lradj == 'type1':
        lr_adjust = {epoch: args.learning_rate * (0.5 ** ((epoch - 1) // 1))}
    elif args.lradj == 'type2':
        lr_adjust = {
            2: 5e-5, 4: 1e-5, 6: 5e-6, 8: 1e-6,
            10: 5e-7, 15: 1e-7, 20: 5e-8
        }
    elif args.lradj == '3':
        lr_adjust = {epoch: args.learning_rate if epoch < 10 else args.learning_rate*0.1}
    elif args.lradj == '4':
        lr_adjust = {epoch: args.learning_rate if epoch < 15 else args.learning_rate*0.1}
    elif args.lradj == '5':
        lr_adjust = {epoch: args.learning_rate if epoch < 25 else args.learning_rate*0.1}
    elif args.lradj == '6':
        lr_adjust = {epoch: args.learning_rate if epoch < 5 else args.learning_rate*0.1}  
    if epoch in lr_adjust.keys():
        lr = lr_adjust[epoch]
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr
        print('Updating learning rate to {}'.format(lr))


class EarlyStopping:
    def __init__(self, patience=7, verbose=False, delta=0):
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta

    def __call__(self, val_loss, model, path):
        score = -val_loss
        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model, path)
        elif score < self.best_score + self.delta:
            self.counter += 1
            print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model, path)
            self.counter = 0

    def save_checkpoint(self, val_loss, model, path):
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}).  Saving model ...')
        torch.save(model.state_dict(), path + '/' + 'checkpoint.pth')
        self.val_loss_min = val_loss


class dotdict(dict):
    """dot.notation access to dictionary attributes"""
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


class StandardScaler():
    def __init__(self, mean, std):
        self.mean = mean
        self.std = std

    def transform(self, data):
        return (data - self.mean) / self.std

    def inverse_transform(self, data):
        return (data * self.std) + self.mean


def visual(true, setting, preds=None, name=None):

    # 使用 SimHei 字体以支持中文显示
    # plt.rcParams['font.family'] = ['WenQuanYi Micro Hei']  # 设置字体为黑体
    plt.rcParams['font.family'] = ['SimHei']  # 设置字体为黑体
    """
    Results visualization
    """
    plt.figure(figsize=(12, 9))
    plt.plot(true, label='真实曲线', linewidth=2)
    if preds is not None:
        plt.plot(preds, label='预测曲线')
    plt.grid()
    # 设置中文横纵坐标标签
    plt.xlabel('时间(秒)', fontsize=14)  # 设置X轴标签为中文

    if 'll6' in setting:
        plt.ylabel('温度(K)', fontsize=18)    # 设置Y轴标签为中文
    elif 'll8' in setting:
         plt.ylabel('长波辐射(W/Sr)', fontsize=18) 
    elif 'll10' in setting:
         plt.ylabel('中波辐射(W/Sr)', fontsize=18) 

    # 设置标题为中文
    plt.title('辐射特性时间序列预测结果')

    plt.legend(fontsize=20)
    plt.savefig(name, dpi=300, bbox_inches='tight')

def test_params_flop(model,x_shape):
    """
    If you want to thest former's flop, you need to give default value to inputs in model.forward(), the following code can only pass one argument to forward()
    """
    model_params = 0
    for parameter in model.parameters():
        model_params += parameter.numel()
        print('INFO: Trainable parameter count: {:.2f}M'.format(model_params / 1000000.0))
    from ptflops import get_model_complexity_info    
    with torch.cuda.device(0):
        macs, params = get_model_complexity_info(model.cuda(), x_shape, as_strings=True, print_per_layer_stat=True)
        # print('Flops:' + flops)
        # print('Params:' + params)
        print('{:<30}  {:<8}'.format('Computational complexity: ', macs))
        print('{:<30}  {:<8}'.format('Number of parameters: ', params))
        
def wavelet_denoise(signal, wavelet='db8', level=1, threshold='soft'):
    """
    使用小波变换对信号进行去噪
    参数:
        signal: 需要去噪的一维信号
        wavelet: 小波基，默认为 'db8'
        level: 小波分解层数，默认为 1
        threshold: 阈值方式，'soft' 代表软阈值，'hard' 代表硬阈值
    返回:
        去噪后的信号
    """
    # 小波分解
    coeffs = pywt.wavedec(signal, wavelet, level=level)
    
    # 根据噪声水平选择阈值
    sigma = np.median(np.abs(coeffs[-level])) / 0.6745
    uthresh = sigma * np.sqrt(2 * np.log(len(signal)))
    
    # 阈值处理
    denoised_coeffs = []
    for i, coeff in enumerate(coeffs):
        if i == 0:  # 对近似系数不做阈值处理
            denoised_coeffs.append(coeff)
        else:
            if threshold == 'soft':
                denoised_coeffs.append(pywt.threshold(coeff, uthresh, mode='soft'))
            else:
                denoised_coeffs.append(pywt.threshold(coeff, uthresh, mode='hard'))
    
    # 小波重构
    denoised_signal = pywt.waverec(denoised_coeffs, wavelet)
    
    return denoised_signal