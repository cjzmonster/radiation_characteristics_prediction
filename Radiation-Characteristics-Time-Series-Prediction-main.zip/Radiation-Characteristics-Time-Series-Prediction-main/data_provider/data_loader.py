import os
import numpy as np
import pandas as pd
import os
import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler
from utils.timefeatures import time_features
import warnings

warnings.filterwarnings('ignore')


class Dataset_ETT_hour(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='S', data_path='ETTh1.csv',
                 target='OT', scale=True, timeenc=0, freq='h'):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path,
                                          self.data_path))

        border1s = [0, 12 * 30 * 24 - self.seq_len, 12 * 30 * 24 + 4 * 30 * 24 - self.seq_len]
        border2s = [12 * 30 * 24, 12 * 30 * 24 + 4 * 30 * 24, 12 * 30 * 24 + 8 * 30 * 24]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            train_data = df_data[border1s[0]:border2s[0]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        df_stamp = df_raw[['date']][border1:border2]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        self.data_x = data[border1:border2]
        self.data_y = data[border1:border2]
        self.data_stamp = data_stamp

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_begin:r_end]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        return seq_x, seq_y, seq_x_mark, seq_y_mark

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)


class Dataset_ETT_minute(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='S', data_path='ETTm1.csv',
                 target='OT', scale=True, timeenc=0, freq='t'):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val', 'ar']
        type_map = {'train': 0, 'val': 1, 'test': 2, 'ar': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path,
                                          self.data_path))

        border1s = [0, 12 * 30 * 24 * 4 - self.seq_len, 12 * 30 * 24 * 4 + 4 * 30 * 24 * 4 - self.seq_len]
        border2s = [12 * 30 * 24 * 4, 12 * 30 * 24 * 4 + 4 * 30 * 24 * 4, 12 * 30 * 24 * 4 + 8 * 30 * 24 * 4]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            train_data = df_data[border1s[0]:border2s[0]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        df_stamp = df_raw[['date']][border1:border2]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            df_stamp['minute'] = df_stamp.date.apply(lambda row: row.minute, 1)
            df_stamp['minute'] = df_stamp.minute.map(lambda x: x // 15)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        self.data_x = data[border1:border2]
        self.data_y = data[border1:border2]
        self.data_stamp = data_stamp

    def __getitem__(self, index):
        s_begin = index    # 100
        s_end = s_begin + self.seq_len    # 100 + 96
        r_begin = s_end - self.label_len    # 100 + 96 - 48 = 148
        r_end = r_begin + self.label_len + self.pred_len    # 148 + 48 + 96 = 196 + 96

        seq_x = self.data_x[s_begin:s_end]    # [100:196]
        seq_y = self.data_y[r_begin:r_end]    # [148:196+96]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        return seq_x, seq_y, seq_x_mark, seq_y_mark

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)


class Dataset_Custom(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='S', data_path='ETTh1.csv',
                 target='OT', scale=True, timeenc=0, freq='h'):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path,
                                          self.data_path))

        '''
        df_raw.columns: ['date', ...(other features), target feature]
        '''
        cols = list(df_raw.columns)
        cols.remove(self.target)
        cols.remove('date')
        df_raw = df_raw[['date'] + cols + [self.target]]
        # print(cols)
        num_train = int(len(df_raw) * 0.7)
        num_test = int(len(df_raw) * 0.2)
        num_vali = len(df_raw) - num_train - num_test
        border1s = [0, num_train - self.seq_len, len(df_raw) - num_test - self.seq_len]
        border2s = [num_train, num_train + num_vali, len(df_raw)]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            train_data = df_data[border1s[0]:border2s[0]]
            self.scaler.fit(train_data.values)
            # print(self.scaler.mean_)
            # exit()
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        df_stamp = df_raw[['date']][border1:border2]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        self.data_x = data[border1:border2]
        self.data_y = data[border1:border2]
        self.data_stamp = data_stamp

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_begin:r_end]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        return seq_x, seq_y, seq_x_mark, seq_y_mark

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)
    

class Dataset_Pred(Dataset):
    def __init__(self, root_path, flag='pred', size=None,
                 features='S', data_path='ETTh1.csv',
                 target='OT', scale=True, inverse=False, timeenc=0, freq='15min', cols=None):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['pred']

        self.features = features
        self.target = target
        self.scale = scale
        self.inverse = inverse
        self.timeenc = timeenc
        self.freq = freq
        self.cols = cols
        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path,
                                          self.data_path))
        '''
        df_raw.columns: ['date', ...(other features), target feature]
        '''
        if self.cols:
            cols = self.cols.copy()
            cols.remove(self.target)
        else:
            cols = list(df_raw.columns)
            cols.remove(self.target)
            cols.remove('date')
        df_raw = df_raw[['date'] + cols + [self.target]]
        border1 = len(df_raw) - self.seq_len
        border2 = len(df_raw)

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            self.scaler.fit(df_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        tmp_stamp = df_raw[['date']][border1:border2]
        tmp_stamp['date'] = pd.to_datetime(tmp_stamp.date)
        pred_dates = pd.date_range(tmp_stamp.date.values[-1], periods=self.pred_len + 1, freq=self.freq)

        df_stamp = pd.DataFrame(columns=['date'])
        df_stamp.date = list(tmp_stamp.date.values) + list(pred_dates[1:])
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            df_stamp['minute'] = df_stamp.date.apply(lambda row: row.minute, 1)
            df_stamp['minute'] = df_stamp.minute.map(lambda x: x // 15)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        self.data_x = data[border1:border2]
        if self.inverse:
            self.data_y = df_data.values[border1:border2]
        else:
            self.data_y = data[border1:border2]
        self.data_stamp = data_stamp

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        if self.inverse:
            seq_y = self.data_x[r_begin:r_begin + self.label_len]
        else:
            seq_y = self.data_y[r_begin:r_begin + self.label_len]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        return seq_x, seq_y, seq_x_mark, seq_y_mark

    def __len__(self):
        return len(self.data_x) - self.seq_len + 1

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)


class Dataset_207(Dataset):
    def __init__(self, root_path = './data/ETT/', flag='train', size=None,
                 features='MS', data_path='data207.csv',
                 target='tmp', scale=True, timeenc=1, freq='s', last = None):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val', 'ar']
        type_map = {'train': 0, 'val': 1, 'test': 2, 'ar': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.last = last

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path,
                                          self.data_path))

        # print('平均值1：', np.mean(df_raw.values[:, -1]))
        data_len_list = [2256, 804, 1373, 1169, 1359, 822, 2248, 1373, 890, 1306, 497, 1378]
        if self.last:
            print('change index: {}'.format(self.last))
            data_len_list.append(data_len_list.pop(self.last-1))
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 2256, 3060, 4433, 5602, 6961, 7783, 10031, 11404, 12294, 13600, 14097, 15475]
        # 1-8 for train, 9-11 for valid, 12 for test
        border1s = [0, 8, 11 ]
        border2s = [8,11,12]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            train_data = df_data[data_len_accumulate[border1s[0]]:data_len_accumulate[border2s[0]]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        df_stamp = df_raw[['date']][data_len_accumulate[border1]:data_len_accumulate[border2]]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            df_stamp['minute'] = df_stamp.date.apply(lambda row: row.minute, 1)
            df_stamp['minute'] = df_stamp.minute.map(lambda x: x // 15)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        self.data_x = data[data_len_accumulate[border1]:data_len_accumulate[border2]]
        self.data_y = data[data_len_accumulate[border1]:data_len_accumulate[border2]]
        self.data_stamp = data_stamp

    def __getitem__(self, index):
        border1s = [0, 8, 11 ]
        border2s = [8,11,12]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]
        data_len_list = [2256, 804, 1373, 1169, 1359, 822, 2248, 1373, 890, 1306, 497, 1378]
        if self.last:
            data_len_list.append(data_len_list.pop(self.last-1))
        data_len_list = data_len_list[border1:border2]
        #[2256, 804, 1373, 1169, 1359, 822] for example
        data_len_list = [i-self.seq_len - self.pred_len + 1 for i in data_len_list] # compute the number of possible sequences in each set
        #[1777, 325, 894, 690, 880, 343] for example
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 1777, 2102, 2996, 3686, 4566, 4909] for example

        i = 0
        while(index > data_len_accumulate[i+1]): i+=1 # find which set
        
        s_begin = index + (self.seq_len + self.pred_len - 1)*i    # transform to the real index
        s_end = s_begin + self.seq_len    # 100 + 96
        r_begin = s_end - self.label_len    # 100 + 96 - 48 = 148
        r_end = r_begin + self.label_len + self.pred_len    # 148 + 48 + 96 = 196 + 96

        seq_x = self.data_x[s_begin:s_end]    # [100:196]
        seq_y = self.data_y[r_begin:r_end]    # [148:196+96]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        return seq_x, seq_y, seq_x_mark, seq_y_mark

    def __len__(self):
        border1s = [0, 8, 11 ]
        border2s = [8,11,12]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]
        data_len_list = [2256, 804, 1373, 1169, 1359, 822, 2248, 1373, 890, 1306, 497, 1378]
        if self.last:
            data_len_list.append(data_len_list.pop(self.last-1))
        data_len_list = [i-self.seq_len - self.pred_len + 1 for i in data_len_list] # compute the number of possible sequences in each set
        #[1777, 325, 894, 690, 880, 343, 1769, 894, 411, 827, 18, 899]
        data_len_list = data_len_list[border1:border2]
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 1777, 2102, 2996, 3686, 4566, 4909] for example
        return data_len_accumulate[-1]

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)

class ascend_with_earth(Dataset):
    def __init__(self, root_path = './data/ascend_with_earth/', flag='train', size=None,
                 features='MS', data_path='data207.csv',
                 target='tmp', scale=True, timeenc=1, freq='s', last = None):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val', 'ar']
        type_map = {'train': 0, 'val': 1, 'test': 2, 'ar': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.last = last

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path,
                                          self.data_path))

        # print('平均值1：', np.mean(df_raw.values[:, -1]))
        data_len_list = [92,66,74,66,95,66,63,66,87,68,118,65]
        if self.last:
            print('change index: {}'.format(self.last))
            index_dic = [0,0,1,2,3,4,0,0,5,0,0,0,0,0,6,7,8,9,10,11,12]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 2256, 3060, 4433, 5602, 6961, 7783, 10031, 11404, 12294, 13600, 14097, 15475]
        # 1-8 for train, 9-11 for valid, 12 for test
        border1s = [0, 8, 11 ]
        border2s = [8,11,12]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            train_data = df_data[data_len_accumulate[border1s[0]]:data_len_accumulate[border2s[0]]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        df_stamp = df_raw[['date']][data_len_accumulate[border1]:data_len_accumulate[border2]]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            df_stamp['minute'] = df_stamp.date.apply(lambda row: row.minute, 1)
            df_stamp['minute'] = df_stamp.minute.map(lambda x: x // 15)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        self.data_x = data[data_len_accumulate[border1]:data_len_accumulate[border2]]
        self.data_y = data[data_len_accumulate[border1]:data_len_accumulate[border2]]
        self.data_stamp = data_stamp

    def __getitem__(self, index):
        border1s = [0, 8, 11 ]
        border2s = [8,11,12]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]
        data_len_list = [92,66,74,66,95,66,63,66,87,68,118,65]
        if self.last:
            index_dic = [0,0,1,2,3,4,0,0,5,0,0,0,0,0,6,7,8,9,10,11,12]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_list = data_len_list[border1:border2]
        #[2256, 804, 1373, 1169, 1359, 822] for example
        data_len_list = [i-self.seq_len - self.pred_len + 1 for i in data_len_list] # compute the number of possible sequences in each set
        #[1777, 325, 894, 690, 880, 343] for example
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 1777, 2102, 2996, 3686, 4566, 4909] for example

        i = 0
        while(index > data_len_accumulate[i+1]): i+=1 # find which set
        
        s_begin = index + (self.seq_len + self.pred_len - 1)*i    # transform to the real index
        s_end = s_begin + self.seq_len    # 100 + 96
        r_begin = s_end - self.label_len    # 100 + 96 - 48 = 148
        r_end = r_begin + self.label_len + self.pred_len    # 148 + 48 + 96 = 196 + 96

        seq_x = self.data_x[s_begin:s_end]    # [100:196]
        seq_y = self.data_y[r_begin:r_end]    # [148:196+96]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]
        
        return seq_x, seq_y, seq_x_mark, seq_y_mark

    def __len__(self):
        border1s = [0, 8, 11 ]
        border2s = [8,11,12]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]
        data_len_list = [92,66,74,66,95,66,63,66,87,68,118,65]
        if self.last:
            index_dic = [0,0,1,2,3,4,0,0,5,0,0,0,0,0,6,7,8,9,10,11,12]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_list = [i-self.seq_len - self.pred_len + 1 for i in data_len_list] # compute the number of possible sequences in each set
        #[1777, 325, 894, 690, 880, 343, 1769, 894, 411, 827, 18, 899]
        data_len_list = data_len_list[border1:border2]
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 1777, 2102, 2996, 3686, 4566, 4909] for example
        return data_len_accumulate[-1]

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)

class ascend_without_earth(Dataset):
    def __init__(self, root_path = './data/ascend_without_earth/', flag='train', size=None,
                 features='MS', data_path='data207.csv',
                 target='tmp', scale=True, timeenc=1, freq='s', last = None):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val', 'ar']
        type_map = {'train': 0, 'val': 1, 'test': 2, 'ar': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.last = last

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path,
                                          self.data_path))

        # print('平均值1：', np.mean(df_raw.values[:, -1]))
        data_len_list = [92,66,74,66,95,66,63,66,87,68,118,65]
        if self.last:
            print('change index: {}'.format(self.last))
            index_dic = [0,0,1,2,3,4,0,0,5,0,0,0,0,0,6,7,8,9,10,11,12]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 2256, 3060, 4433, 5602, 6961, 7783, 10031, 11404, 12294, 13600, 14097, 15475]
        # 1-8 for train, 9-11 for valid, 12 for test
        border1s = [0, 8, 11 ]
        border2s = [8,11,12]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            train_data = df_data[data_len_accumulate[border1s[0]]:data_len_accumulate[border2s[0]]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        df_stamp = df_raw[['date']][data_len_accumulate[border1]:data_len_accumulate[border2]]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            df_stamp['minute'] = df_stamp.date.apply(lambda row: row.minute, 1)
            df_stamp['minute'] = df_stamp.minute.map(lambda x: x // 15)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        self.data_x = data[data_len_accumulate[border1]:data_len_accumulate[border2]]
        self.data_y = data[data_len_accumulate[border1]:data_len_accumulate[border2]]
        self.data_stamp = data_stamp

    def __getitem__(self, index):
        border1s = [0, 8, 11 ]
        border2s = [8,11,12]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]
        data_len_list = [92,66,74,66,95,66,63,66,87,68,118,65]
        if self.last:
            index_dic = [0,0,1,2,3,4,0,0,5,0,0,0,0,0,6,7,8,9,10,11,12]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_list = data_len_list[border1:border2]
        #[2256, 804, 1373, 1169, 1359, 822] for example
        data_len_list = [i-self.seq_len - self.pred_len + 1 for i in data_len_list] # compute the number of possible sequences in each set
        #[1777, 325, 894, 690, 880, 343] for example
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 1777, 2102, 2996, 3686, 4566, 4909] for example

        i = 0
        while(index > data_len_accumulate[i+1]): i+=1 # find which set
        
        s_begin = index + (self.seq_len + self.pred_len - 1)*i    # transform to the real index
        s_end = s_begin + self.seq_len    # 100 + 96
        r_begin = s_end - self.label_len    # 100 + 96 - 48 = 148
        r_end = r_begin + self.label_len + self.pred_len    # 148 + 48 + 96 = 196 + 96

        seq_x = self.data_x[s_begin:s_end]    # [100:196]
        seq_y = self.data_y[r_begin:r_end]    # [148:196+96]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        return seq_x, seq_y, seq_x_mark, seq_y_mark

    def __len__(self):
        border1s = [0, 8, 11 ]
        border2s = [8,11,12]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]
        data_len_list = [92,66,74,66,95,66,63,66,87,68,118,65]
        if self.last:
            index_dic = [0,0,1,2,3,4,0,0,5,0,0,0,0,0,6,7,8,9,10,11,12]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_list = [i-self.seq_len - self.pred_len + 1 for i in data_len_list] # compute the number of possible sequences in each set
        #[1777, 325, 894, 690, 880, 343, 1769, 894, 411, 827, 18, 899]
        data_len_list = data_len_list[border1:border2]
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 1777, 2102, 2996, 3686, 4566, 4909] for example
        return data_len_accumulate[-1]

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)

class middle_with_earth(Dataset):
    def __init__(self, root_path = './data/middle_with_earth/', flag='train', size=None,
                 features='MS', data_path='data207.csv',
                 target='tmp', scale=True, timeenc=1, freq='s', last = None):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val', 'ar']
        type_map = {'train': 0, 'val': 1, 'test': 2, 'ar': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.last = last

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path,
                                          self.data_path))

        # print('平均值1：', np.mean(df_raw.values[:, -1]))
        data_len_list = [2256,804,1373,1169,1359,822,2248,440,450,1373,890,1306,497,1378]
        if self.last:
            print('change index: {}'.format(self.last))
            index_dic = [0,1,2,3,4,5,0,0,6,0,7,0,0,0,8,9,10,11,12,13,14]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 2256, 3060, 4433, 5602, 6961, 7783, 10031, 11404, 12294, 13600, 14097, 15475]
        # 1-8 for train, 9-11 for valid, 12 for test
        border1s = [0, 10, 13 ]
        border2s = [10,13,14]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            train_data = df_data[data_len_accumulate[border1s[0]]:data_len_accumulate[border2s[0]]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        df_stamp = df_raw[['date']][data_len_accumulate[border1]:data_len_accumulate[border2]]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            df_stamp['minute'] = df_stamp.date.apply(lambda row: row.minute, 1)
            df_stamp['minute'] = df_stamp.minute.map(lambda x: x // 15)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        self.data_x = data[data_len_accumulate[border1]:data_len_accumulate[border2]]
        self.data_y = data[data_len_accumulate[border1]:data_len_accumulate[border2]]
        self.data_stamp = data_stamp

    def __getitem__(self, index):
        border1s = [0, 10, 13 ]
        border2s = [10,13,14]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]
        data_len_list = [2256,804,1373,1169,1359,822,2248,440,450,1373,890,1306,497,1378]
        if self.last:
            index_dic = [0,1,2,3,4,5,0,0,6,0,7,0,0,0,8,9,10,11,12,13,14]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_list = data_len_list[border1:border2]
        #[2256, 804, 1373, 1169, 1359, 822] for example
        data_len_list = [i-self.seq_len - self.pred_len + 1 for i in data_len_list] # compute the number of possible sequences in each set
        #[1777, 325, 894, 690, 880, 343] for example
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 1777, 2102, 2996, 3686, 4566, 4909] for example

        i = 0
        while(index > data_len_accumulate[i+1]): i+=1 # find which set
        
        s_begin = index + (self.seq_len + self.pred_len - 1)*i    # transform to the real index
        s_end = s_begin + self.seq_len    # 100 + 96
        r_begin = s_end - self.label_len    # 100 + 96 - 48 = 148
        r_end = r_begin + self.label_len + self.pred_len    # 148 + 48 + 96 = 196 + 96

        seq_x = self.data_x[s_begin:s_end]    # [100:196]
        seq_y = self.data_y[r_begin:r_end]    # [148:196+96]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        return seq_x, seq_y, seq_x_mark, seq_y_mark

    def __len__(self):
        border1s = [0, 10, 13 ]
        border2s = [10,13,14]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]
        data_len_list = [2256,804,1373,1169,1359,822,2248,440,450,1373,890,1306,497,1378]
        if self.last:
            index_dic = [0,1,2,3,4,5,0,0,6,0,7,0,0,0,8,9,10,11,12,13,14]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_list = [i-self.seq_len - self.pred_len + 1 for i in data_len_list] # compute the number of possible sequences in each set
        #[1777, 325, 894, 690, 880, 343, 1769, 894, 411, 827, 18, 899]
        data_len_list = data_len_list[border1:border2]
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 1777, 2102, 2996, 3686, 4566, 4909] for example
        return data_len_accumulate[-1]

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)

class middle_without_earth(Dataset):
    def __init__(self, root_path = './data/middle_without_earth/', flag='train', size=None,
                 features='MS', data_path='data207.csv',
                 target='tmp', scale=True, timeenc=1, freq='s', last = None):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val', 'ar']
        type_map = {'train': 0, 'val': 1, 'test': 2, 'ar': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.last = last

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path,
                                          self.data_path))

        # print('平均值1：', np.mean(df_raw.values[:, -1]))
        data_len_list = [2256,804,1373,1169,1359,822,2248,440,450,1373,890,1306,497,1378]
        if self.last:
            print('change index: {}'.format(self.last))
            index_dic = [0,1,2,3,4,5,0,0,6,0,7,0,0,0,8,9,10,11,12,13,14]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 2256, 3060, 4433, 5602, 6961, 7783, 10031, 11404, 12294, 13600, 14097, 15475]
        # 1-8 for train, 9-11 for valid, 12 for test
        border1s = [0, 10, 13 ]
        border2s = [10,13,14]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            train_data = df_data[data_len_accumulate[border1s[0]]:data_len_accumulate[border2s[0]]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        df_stamp = df_raw[['date']][data_len_accumulate[border1]:data_len_accumulate[border2]]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            df_stamp['minute'] = df_stamp.date.apply(lambda row: row.minute, 1)
            df_stamp['minute'] = df_stamp.minute.map(lambda x: x // 15)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        self.data_x = data[data_len_accumulate[border1]:data_len_accumulate[border2]]
        self.data_y = data[data_len_accumulate[border1]:data_len_accumulate[border2]]
        self.data_stamp = data_stamp

    def __getitem__(self, index):
        border1s = [0, 10, 13 ]
        border2s = [10,13,14]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]
        data_len_list = [2256,804,1373,1169,1359,822,2248,440,450,1373,890,1306,497,1378]
        if self.last:
            index_dic = [0,1,2,3,4,5,0,0,6,0,7,0,0,0,8,9,10,11,12,13,14]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_list = data_len_list[border1:border2]
        #[2256, 804, 1373, 1169, 1359, 822] for example
        data_len_list = [i-self.seq_len - self.pred_len + 1 for i in data_len_list] # compute the number of possible sequences in each set
        #[1777, 325, 894, 690, 880, 343] for example
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 1777, 2102, 2996, 3686, 4566, 4909] for example

        i = 0
        while(index > data_len_accumulate[i+1]): i+=1 # find which set
        
        s_begin = index + (self.seq_len + self.pred_len - 1)*i    # transform to the real index
        s_end = s_begin + self.seq_len    # 100 + 96
        r_begin = s_end - self.label_len    # 100 + 96 - 48 = 148
        r_end = r_begin + self.label_len + self.pred_len    # 148 + 48 + 96 = 196 + 96

        seq_x = self.data_x[s_begin:s_end]    # [100:196]
        seq_y = self.data_y[r_begin:r_end]    # [148:196+96]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        return seq_x, seq_y, seq_x_mark, seq_y_mark

    def __len__(self):
        border1s = [0, 10, 13 ]
        border2s = [10,13,14]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]
        data_len_list = [2256,804,1373,1169,1359,822,2248,440,450,1373,890,1306,497,1378]
        if self.last:
            index_dic = [0,1,2,3,4,5,0,0,6,0,7,0,0,0,8,9,10,11,12,13,14]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_list = [i-self.seq_len - self.pred_len + 1 for i in data_len_list] # compute the number of possible sequences in each set
        #[1777, 325, 894, 690, 880, 343, 1769, 894, 411, 827, 18, 899]
        data_len_list = data_len_list[border1:border2]
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 1777, 2102, 2996, 3686, 4566, 4909] for example
        return data_len_accumulate[-1]

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)

class whole_with_earth(Dataset):
    def __init__(self, root_path = './data/whole_with_earth/', flag='train', size=None,
                 features='MS', data_path='data207.csv',
                 target='tmp', scale=True, timeenc=1, freq='s', last = None):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val', 'ar']
        type_map = {'train': 0, 'val': 1, 'test': 2, 'ar': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.last = last

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path,
                                          self.data_path))

        # print('平均值1：', np.mean(df_raw.values[:, -1]))
        data_len_list = [896,1439,1243,1425,917,506,513,1439,977,1374,615,1443]
        if self.last:
            print('change index: {}'.format(self.last))
            index_dic = [0,0,1,2,3,4,0,0,5,0,0,0,0,0,6,7,8,9,10,11,12]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 2256, 3060, 4433, 5602, 6961, 7783, 10031, 11404, 12294, 13600, 14097, 15475]
        # 1-8 for train, 9-11 for valid, 12 for test
        border1s = [0, 8, 11 ]
        border2s = [8,11,12]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            train_data = df_data[data_len_accumulate[border1s[0]]:data_len_accumulate[border2s[0]]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        df_stamp = df_raw[['date']][data_len_accumulate[border1]:data_len_accumulate[border2]]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            df_stamp['minute'] = df_stamp.date.apply(lambda row: row.minute, 1)
            df_stamp['minute'] = df_stamp.minute.map(lambda x: x // 15)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        self.data_x = data[data_len_accumulate[border1]:data_len_accumulate[border2]]
        self.data_y = data[data_len_accumulate[border1]:data_len_accumulate[border2]]
        self.data_stamp = data_stamp

    def __getitem__(self, index):
        border1s = [0, 8, 11 ]
        border2s = [8,11,12]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]
        data_len_list = [896,1439,1243,1425,917,506,513,1439,977,1374,615,1443]
        if self.last:
            index_dic = [0,0,1,2,3,4,0,0,5,0,0,0,0,0,6,7,8,9,10,11,12]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_list = data_len_list[border1:border2]
        #[2256, 804, 1373, 1169, 1359, 822] for example
        data_len_list = [i-self.seq_len - self.pred_len + 1 for i in data_len_list] # compute the number of possible sequences in each set
        #[1777, 325, 894, 690, 880, 343] for example
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 1777, 2102, 2996, 3686, 4566, 4909] for example

        i = 0
        while(index > data_len_accumulate[i+1]): i+=1 # find which set
        
        s_begin = index + (self.seq_len + self.pred_len - 1)*i    # transform to the real index
        s_end = s_begin + self.seq_len    # 100 + 96
        r_begin = s_end - self.label_len    # 100 + 96 - 48 = 148
        r_end = r_begin + self.label_len + self.pred_len    # 148 + 48 + 96 = 196 + 96

        seq_x = self.data_x[s_begin:s_end]    # [100:196]
        seq_y = self.data_y[r_begin:r_end]    # [148:196+96]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        return seq_x, seq_y, seq_x_mark, seq_y_mark

    def __len__(self):
        border1s = [0, 8, 11 ]
        border2s = [8,11,12]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]
        data_len_list = [896,1439,1243,1425,917,506,513,1439,977,1374,615,1443]
        if self.last:
            index_dic = [0,0,1,2,3,4,0,0,5,0,0,0,0,0,6,7,8,9,10,11,12]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_list = [i-self.seq_len - self.pred_len + 1 for i in data_len_list] # compute the number of possible sequences in each set
        #[1777, 325, 894, 690, 880, 343, 1769, 894, 411, 827, 18, 899]
        data_len_list = data_len_list[border1:border2]
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 1777, 2102, 2996, 3686, 4566, 4909] for example
        return data_len_accumulate[-1]

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)

class whole_without_earth(Dataset):
    def __init__(self, root_path = './data/whole_without_earth/', flag='train', size=None,
                 features='MS', data_path='data207.csv',
                 target='tmp', scale=True, timeenc=1, freq='s', last = None):
        # size [seq_len, label_len, pred_len]
        # info
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val', 'ar']
        type_map = {'train': 0, 'val': 1, 'test': 2, 'ar': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.last = last

        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path,
                                          self.data_path))

        # print('平均值1：', np.mean(df_raw.values[:, -1]))
        data_len_list = [896,1439,1243,1425,917,506,513,1439,977,1374,615,1443]
        if self.last:
            print('change index: {}'.format(self.last))
            index_dic = [0,0,1,2,3,4,0,0,5,0,0,0,0,0,6,7,8,9,10,11,12]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 2256, 3060, 4433, 5602, 6961, 7783, 10031, 11404, 12294, 13600, 14097, 15475]
        # 1-8 for train, 9-11 for valid, 12 for test
        border1s = [0, 8, 11 ]
        border2s = [8,11,12]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            train_data = df_data[data_len_accumulate[border1s[0]]:data_len_accumulate[border2s[0]]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        df_stamp = df_raw[['date']][data_len_accumulate[border1]:data_len_accumulate[border2]]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            df_stamp['minute'] = df_stamp.date.apply(lambda row: row.minute, 1)
            df_stamp['minute'] = df_stamp.minute.map(lambda x: x // 15)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        self.data_x = data[data_len_accumulate[border1]:data_len_accumulate[border2]]
        self.data_y = data[data_len_accumulate[border1]:data_len_accumulate[border2]]
        self.data_stamp = data_stamp

    def __getitem__(self, index):
        border1s = [0, 8, 11 ]
        border2s = [8,11,12]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]
        data_len_list = [896,1439,1243,1425,917,506,513,1439,977,1374,615,1443]
        if self.last:
            index_dic = [0,0,1,2,3,4,0,0,5,0,0,0,0,0,6,7,8,9,10,11,12]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_list = data_len_list[border1:border2]
        #[2256, 804, 1373, 1169, 1359, 822] for example
        data_len_list = [i-self.seq_len - self.pred_len + 1 for i in data_len_list] # compute the number of possible sequences in each set
        #[1777, 325, 894, 690, 880, 343] for example
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 1777, 2102, 2996, 3686, 4566, 4909] for example

        i = 0
        while(index > data_len_accumulate[i+1]): i+=1 # find which set
        
        s_begin = index + (self.seq_len + self.pred_len - 1)*i    # transform to the real index
        s_end = s_begin + self.seq_len    # 100 + 96
        r_begin = s_end - self.label_len    # 100 + 96 - 48 = 148
        r_end = r_begin + self.label_len + self.pred_len    # 148 + 48 + 96 = 196 + 96

        seq_x = self.data_x[s_begin:s_end]    # [100:196]
        seq_y = self.data_y[r_begin:r_end]    # [148:196+96]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        return seq_x, seq_y, seq_x_mark, seq_y_mark

    def __len__(self):
        border1s = [0, 8, 11 ]
        border2s = [8,11,12]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]
        data_len_list = [896,1439,1243,1425,917,506,513,1439,977,1374,615,1443]
        if self.last:
            index_dic = [0,0,1,2,3,4,0,0,5,0,0,0,0,0,6,7,8,9,10,11,12]
            data_len_list.append(data_len_list.pop(index_dic[self.last]-1))
        data_len_list = [i-self.seq_len - self.pred_len + 1 for i in data_len_list] # compute the number of possible sequences in each set
        #[1777, 325, 894, 690, 880, 343, 1769, 894, 411, 827, 18, 899]
        data_len_list = data_len_list[border1:border2]
        data_len_accumulate = [int(np.sum(data_len_list[:i])) for i in range(len(data_len_list)+1)]
        #[0, 1777, 2102, 2996, 3686, 4566, 4909] for example
        return data_len_accumulate[-1]

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)
    
    
class Dataset_207_40(Dataset):
    def __init__(self, args, root_path, flag='train', size=None,
                 features='MS', data_path='data207.csv',
                 target='tmp', scale=True, timeenc=0, freq='s'):
        # size [seq_len, label_len, pred_len]
        # info
        self.args = args
        if size == None:
            self.seq_len = 24 * 4 * 4
            self.label_len = 24 * 4
            self.pred_len = 24 * 4
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        # init
        assert flag in ['train', 'test', 'val', 'ar']
        type_map = {'train': 0, 'val': 1, 'test': 2, 'ar': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq

        self.root_path = root_path
        self.data_path = data_path

        self.data = pd.read_csv(os.path.join(self.root_path, self.data_path))

        if self.args.test_new:
            # 将40条之外的新测试数据与40条数据合并
            df_test = pd.read_excel(os.path.join(self.root_path, 'test.xlsx'))
            constant_params = df_test.iloc[:10, 1].values
            repeated_params = np.tile(constant_params, (len(df_test), 1))
            dynamic_data = df_test.iloc[:, [2, 3, 4, 5, 6, 7]].values
            combined_data = np.hstack([repeated_params, dynamic_data])
            # combined_data[args.seq_len:, -3] = 100

            df_combined = pd.DataFrame(combined_data, columns=['param1', 'param2', 'param3', 'param4', 'param5', 'param6', 'param7',
       'param8', 'param9', 'param10', 'time', 'height', 'speed', 'tmp',
       'radio1', 'radio2'])
            date_data_combined = pd.date_range(start='2024-07-01 08:00:00', periods=len(df_combined), freq='S')
            df_combined['date'] = date_data_combined
            df_combined = df_combined[['date','param1','param2','param3','param4','param5','param6','param7','param8','param9','param10','height','speed','tmp','radio1','radio2']]
            df_merged = pd.concat([self.data, df_combined], ignore_index=True)
            df_merged['date'] = pd.to_datetime(df_merged['date'])
            self.data = df_merged
            # self.data.to_csv('aaa.csv')

        self.whole_sequences, self.train_sequences, self.val_sequences, self.test_sequences = self.split_sequences()
        self.set_mode()
        self.__read_data__()

    def split_sequences(self):
        sequences = []
        current_sequence_start = 0

        for i in range(1, len(self.data)):
            # 假设每个序列的时间列为 'timestamp'，时间戳应该是递增的
            if self.data.iloc[i]['date'] < self.data.iloc[i - 1]['date']:
                # 找到时间戳重置点，标记新序列的开始
                sequences.append((current_sequence_start, i))
                current_sequence_start = i
        # 加入最后一个序列
        sequences.append((current_sequence_start, len(self.data)))

        num_sequences = len(sequences)
        # train_sequences = sequences[:int(num_sequences * 0.75)]
        # val_sequences = sequences[int(num_sequences * 0.75):int(num_sequences * 0.875)]
        # test_sequences = sequences[int(num_sequences * 0.875):]
        train_sequences = sequences[:35]
        val_sequences = sequences[35:num_sequences-1]
        test_sequences = sequences[num_sequences-1:]
        return sequences, train_sequences, val_sequences, test_sequences

    def set_mode(self):
        if self.set_type == 0:
            self.sequences = self.train_sequences
        elif self.set_type == 1:
            self.sequences = self.val_sequences
        elif self.set_type == 2:
            self.sequences = self.test_sequences
        else:
            raise ValueError("Mode should be 'train', 'val', or 'test'")

    def __read_data__(self):
        self.scaler = StandardScaler()
        # df_raw = pd.read_csv(os.path.join(self.root_path,
        #                                   self.data_path))
        df_raw = self.data

        # border1s = [0, self.whole_sequences[29][1], self.whole_sequences[34][1]]
        # border2s = [self.whole_sequences[29][1], self.whole_sequences[34][1], self.whole_sequences[39][1]]
        border1s = [0, self.whole_sequences[34][1], self.whole_sequences[len(self.whole_sequences)-2][1]]
        border2s = [self.whole_sequences[34][1], self.whole_sequences[len(self.whole_sequences)-2][1], self.whole_sequences[len(self.whole_sequences)-1][1]]
        border1 = border1s[self.set_type]
        border2 = border2s[self.set_type]

        if self.features == 'M' or self.features == 'MS':
            if self.target == 'tmp':
                cols_data = df_raw.columns[1:-2]
                df_data = df_raw[cols_data]
            elif self.target == 'radio1':
                df_data = pd.concat([df_raw.iloc[:, 1:-3], df_raw.iloc[:, -2]], axis=1)
            elif self.target == 'radio2':
                df_data = pd.concat([df_raw.iloc[:, 1:-3], df_raw.iloc[:, -1]], axis=1)
            # df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        if self.scale:
            train_data = df_data[border1s[0]:border2s[0]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        # df_stamp = df_raw[['date']][border1:border2]
        df_stamp = df_raw[['date']]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            df_stamp['minute'] = df_stamp.date.apply(lambda row: row.minute, 1)
            df_stamp['minute'] = df_stamp.minute.map(lambda x: x // 15)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        # self.data_x = data[border1:border2]
        # self.data_y = data[border1:border2]

        self.data_x = data
        self.data_y = data
        self.data_stamp = data_stamp

    def __getitem__(self, idx):
        for start, end in self.sequences:
            if idx < end - start - self.seq_len + 1:
                s_begin = start + idx
                s_end = s_begin + self.seq_len
                r_begin = s_end - self.label_len    # 100 + 96 - 48 = 148
                r_end = r_begin + self.label_len + self.pred_len    # 148 + 48 + 96 = 196 + 96
                seq_x = self.data_x[s_begin:s_end]    # [100:196]
                seq_y = self.data_y[r_begin:r_end]    # [148:196+96]
                seq_x_mark = self.data_stamp[s_begin:s_end]
                seq_y_mark = self.data_stamp[r_begin:r_end]
                return seq_x, seq_y, seq_x_mark, seq_y_mark
                # return self.data.iloc[sequence_start:sequence_end].values
            idx -= end - start - self.seq_len + 1
        raise IndexError("Index out of range")

    def __len__(self):
        # print(self.sequences)
        # print(sum([end - start - self.seq_len + 1 for start, end in self.sequences]))
        return sum([end - start - self.seq_len + 1 for start, end in self.sequences])

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)

    

if __name__ == '__main__':
    Dataset_207()
    
    a = [896, 1200, 715, 1200, 1200, 1200, 1200, 1200, 977, 1200, 1200, 1200, 1200, 1122, 1200, 715, 1200, 1200, 1200, 896, 
                         1200, 1200, 1200, 1200, 1200, 1122, 1200, 977, 1200, 715, 977, 1053, 1053, 1200, 809, 615, 809, 1185, 615, 1185]